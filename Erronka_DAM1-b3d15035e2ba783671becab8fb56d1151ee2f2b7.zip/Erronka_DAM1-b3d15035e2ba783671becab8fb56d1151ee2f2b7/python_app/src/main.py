from src.view import optionsMenu

optionsMenu.printMainMenu()
