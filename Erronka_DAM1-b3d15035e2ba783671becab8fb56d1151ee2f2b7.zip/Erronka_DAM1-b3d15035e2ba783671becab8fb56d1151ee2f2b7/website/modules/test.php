<?php
include("../model/MySQLPDO.class.php");
phpinfo();
?>